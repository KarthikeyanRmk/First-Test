package forms;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriverException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import excel_Data.Exceldata;
import utils.Dataprovider;
import wrappers.Office;

public class Testng_Refer_form_New_imp extends Office {
	Properties prop;
	{
		prop = new Properties();
		try {
			prop.load(new FileInputStream(new File("./referaFriend.properties")));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	String dataSheetName;

	@Override
	@DataProvider(name = "scenario1")
	public Object[][] getData() {
		return Dataprovider.getSheet(dataSheetName);
	}

	@BeforeClass
	public void beforeClass() {
		dataSheetName = "Forms";
		testCaseName = "Forms Submitting";
		testDescription = "Refer a Friend Form Submission";
	}

	@Test(dataProvider = "scenario1")
	public void sceranio1(String dropdown1, String firstN, String lastN, String addrs, String city, String zip,
			String state, String phone, String phone_ab_acc, String email, String friend_1_first_name,
			String friend_1_last_name, String friend_1_phone, String friend_1_zip, String friend_1_email, String error,
			String QAresults) {

		invokeApp("chrome", "http://abbwebsiteqa.shastatek.com/my-services/my-account/refer-a-friend");

		selectVisibileTextById("how_did_you_hear", dropdown1);
		enterById("first_name", firstN);
		enterById("last_name", lastN);
		enterById("address", addrs);
		enterById("city", city);
		enterById("zip", zip);
		selectVisibileTextById("state", state);
		enterById("phone", phone);
		enterById("phone_ab_account", phone_ab_acc);
		enterById("email", email);
		enterById("friend_1_first_name", friend_1_first_name);
		enterById("friend_1_last_name", friend_1_last_name);
		enterById("friend_1_phone", friend_1_phone);
		enterById("friend_1_zip", friend_1_zip);
		enterById("friend_1_email", friend_1_email);
		clickByCssSelector("input[ type=\"submit\"]");
		String Error = driver.findElementByXPath("//div[@class='messaging error']").getText();
		System.out.println(Error);
		String SheetName = "TCOO1";
		Exceldata er = new Exceldata();
		try {
			for (int i = 1; i <= er.RowCount(SheetName); i++) {
				try {
					// er.ReadFromCell(i, 15, SheetName);
					// String Result=er.ReadFromCell(i, 15, SheetName);
					System.out.println("\n\n" + Error + "\n\n" + error + "\n\n");
					if (Error.contains(error)) {
						er.AddReport("Pass", SheetName, i, 16);

					} else {
						er.AddReport("Fail", SheetName, i, 16);
					}

				}

				catch (WebDriverException e) {
					System.out.println(e);
					er.AddReport("Execution failed", SheetName, i, 16);
				}
			}
		} catch (InterruptedException e) {

			e.printStackTrace();
		} catch (Exception e) {

			e.printStackTrace();
		}

		driver.close();

	}

}
