package excel_Data;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Exceldata {
	private XSSFSheet ExcelWSheet;
	private XSSFWorkbook ExcelWBook;
	private XSSFCell Cell;
	private XSSFRow Row;
	String Path="./Data/Forms.xlsx";




	public int RowCount(String SheetName) throws Exception
	{
		FileInputStream fis =new FileInputStream(new File(Path));
		ExcelWBook=new XSSFWorkbook(fis);
		ExcelWSheet = ExcelWBook.getSheet(SheetName);
		int RowCount=ExcelWSheet.getLastRowNum();
		return RowCount;
	}


	public void AddReport(String Error, String SheetName, int i,int col) 

	{
		try {

			FileInputStream Fi = new FileInputStream(new File(Path));

			XSSFWorkbook Wb = new XSSFWorkbook(Fi);
			XSSFSheet Ws = Wb.getSheet(SheetName);
			int rowcount = Ws.getLastRowNum();
			XSSFRow Wr = Ws.getRow(i);
			Row = Ws.getRow(col);
			Wr.createCell(16).setCellValue(Error);
			FileOutputStream fo = new FileOutputStream(new File(Path));
			Wb.write(fo);
			fo.close();
			fo.flush();

		} catch (FileNotFoundException e) {

			System.out.println("FileNotFoundException");

		} catch (IOException e) {

			System.out.println("IOException");
		}

	}




	public String ReadFromCell(int RowNo, int ColNo, String SheetName)
			throws Exception

	{
		FileInputStream fis = new FileInputStream(new File(Path));
		XSSFWorkbook Wb = new XSSFWorkbook(fis);
		XSSFSheet Ws = Wb.getSheet(SheetName);
		XSSFRow Row = Ws.getRow(RowNo);
		String str = Row.getCell(ColNo).getStringCellValue();
		return str;

	}



	public String getCellData(int RowNum,int ColNum,String SheetName) throws Exception
	{
		FileInputStream fis =new FileInputStream(new File(Path));
		ExcelWBook=new XSSFWorkbook(fis);
		ExcelWSheet = ExcelWBook.getSheet(SheetName);
		Row=ExcelWSheet.getRow(RowNum);
		String res=Row.getCell(ColNum).getStringCellValue();
		return res;		

	}





}








