package test_Sample;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class String_split {

	public static void main(String [] arg)
	{

		String string1 = "ab bc   cd   de";
		String string2="bc cd de aCCC";

		String[] parts1 = string1.split("\\s+");
		String part1 = parts1[0]; 
		String part2 = parts1[1];
		String part3 = parts1[2];
		String part4 = parts1[3];


		String[] parts2 = string2.split("\\s+");
		String stringtwopart1 = parts2[0]; 
		String stringtwopart2 = parts2[1];
		String stringtwopart3= parts2[2];
		String stringtwopart4= parts2[3];

		ArrayList<String> ar1 = new ArrayList<String>();

		ar1.add(part1);
		ar1.add(part2);
		ar1.add(part3);
		ar1.add(part4);


		ArrayList<String> ar2 = new ArrayList<String>();

		ar2.add(stringtwopart1);
		ar2.add(stringtwopart2);
		ar2.add(stringtwopart3);
		ar2.add(stringtwopart4);

		List<String> s1List = new ArrayList<String>(ar1);
		List<String> s2List = new ArrayList<String>(ar2);
		s1List.removeAll(ar2);
		s2List.removeAll(ar1);

		System.out.println("String 1 splitup");
		System.out.println(part1);
		System.out.println(part2);
		System.out.println(part3);
		System.out.println(part4);
		System.out.println("String 2 splitup");
		System.out.println(stringtwopart1);
		System.out.println(stringtwopart2);
		System.out.println(stringtwopart3);
		System.out.println(stringtwopart4);

		System.out.println("Final output "+s1List+" " +s2List);
	}

}
