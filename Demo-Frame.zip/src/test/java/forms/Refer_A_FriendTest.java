package forms;

import org.testng.annotations.Test;

public class Refer_A_FriendTest {
  @Test
  public void f() {
	  System.out.println("");
  }
}
