package forms;

import org.testng.annotations.Test;


import utils.Dataprovider;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import wrappers.Generic_Wrappers;

public class Testng_Refer_form extends Generic_Wrappers{

	String dataSheetName;
	@BeforeClass
	public void beforeClass() {
		dataSheetName="Forms";
		
	}
	@DataProvider(name="scenario1")
	public Object[][] getData()
	{
		return Dataprovider.getSheet(dataSheetName);
			/*	{
			{"Bill Message","test","test","testaddrss","testcity","62611","California","9876543210","9876543210123456","test@gmail.com","firsttest","lasttest","9876543210","06632","test@gmail.com"},
		{"Bill Message","test","test","testaddrss","testcity","62611","California","9876543210","9876543210123456","test@gmail.com","firsttest","lasttest","9876543210","06632",""},
		{"Bill Message","test","test","testaddrss","testcity","62611","California","9876543210","9876543210123456","test@gmail.com","firsttest","lasttest","9876543210","",""},
			{"Bill Message","test","test","testaddrss","testcity","62611","California","9876543210","9876543210123456","test@gmail.com","firsttest","lasttest","","",""},
			{"Bill Message","test","test","testaddrss","testcity","62611","California","9876543210","9876543210123456","test@gmail.com","firsttest","","","",""},
			{"Bill Message","test","test","testaddrss","testcity","62611","California","9876543210","9876543210123456","test@gmail.com","","","","",""},
			{"Bill Message","test","test","testaddrss","testcity","62611","California","9876543210","9876543210123456","","","","","",""},
			{"Bill Message","test","test","testaddrss","testcity","62611","California","9876543210","","","","","","",""},
			{"Bill Message","test","test","testaddrss","testcity","62611","California","","","","","","","",""},
			{"Bill Message","test","test","testaddrss","testcity","62611","","","","","","","","",""},
			{"Bill Message","test","test","testaddrss","testcity","","","","","","","","","",""},
			{"Bill Message","test","test","testaddrss","","","","","","","","","","",""},
			{"Bill Message","test","test","","","","","","","","","","","",""},
			{"Bill Message","test","","","","","","","","","","","","",""},
			{"Bill Message","","","","","","","","","","","","","",""},
			{"","","","","","","","","","","","","","",""}
				
				};*/}
	@Test(dataProvider="scenario1")
	public void sceranio1(String dropdown1,String firstN,String lastN,String addrs,
			String city,String zip,String state,String phone,String phone_ab_acc,
			String email,String	friend_1_first_name,String friend_1_last_name,String friend_1_phone,
			String friend_1_zip,
			String friend_1_email,String error,String QAresults)
	{  
		invokeApp("chrome","http://abbwebsiteqa.shastatek.com/my-services/my-account/refer-a-friend");
	
	selectVisibileTextById("how_did_you_hear", dropdown1);
		enterById("first_name",firstN);
		enterById("last_name",lastN);
		enterById("address",addrs);
		enterById("city",city);
		enterById("zip",zip);
		selectVisibileTextById("state", state);
		enterById("phone",phone);
		enterById("phone_ab_account",phone_ab_acc);
		enterById("email",email);
		enterById("friend_1_first_name",friend_1_first_name);
		enterById("friend_1_last_name",friend_1_last_name);
		enterById("friend_1_phone",friend_1_phone);
		enterById("friend_1_zip",friend_1_zip);
		enterById("friend_1_email",friend_1_email);
		clickByCssSelector("input[ type=\"submit\"]");
		List<WebElement> line=driver.findElementsByXPath("//*[@id='refer_a_friend']/div/div/section/div/ul/li");
		int j=line.size();
		System.out.println( "Scenario 1:Total Error Count "+j);
		for ( int i=0; i < line.size(); i++) {
			System.out.println(line.get(i).getText());
		}
		
		
		
		if (j==0)
			System.out.println("Form submit successfully");
		else
			System.out.println("Form submission have some  error");
		System.out.println("");
		driver.quit();


	}

	
}






