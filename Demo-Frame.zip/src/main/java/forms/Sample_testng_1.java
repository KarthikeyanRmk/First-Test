package forms;

import org.testng.annotations.Test;

public class Sample_testng_1 {
  @Test
  public void f() {
	
	  System.out.println("helo ");
  }
}
