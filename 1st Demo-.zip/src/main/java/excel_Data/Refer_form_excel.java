package excel_Data;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Refer_form_excel {
	
	public static void main(String [] arg){
	XSSFSheet ExcelWSheet = null;

		 XSSFWorkbook ExcelWBook;
		 XSSFCell Cell;
		 XSSFRow Row;
		
		try {
			String fileInput = "D:\\sel\\Data\\Refer_Friend_Form.xlsx";
			ExcelWBook = new XSSFWorkbook(fileInput);
			ExcelWSheet = ExcelWBook.getSheetAt(0);
			
			String dropdown1 = ExcelWSheet.getRow(1).getCell(0).getStringCellValue();
			System.out.println(dropdown1);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e);
		}
		
		

		
		
		
	}
}