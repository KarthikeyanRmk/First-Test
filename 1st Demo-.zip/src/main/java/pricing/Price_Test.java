package pricing;

import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import wrappers.Generic_Wrappers;

public class Price_Test extends Generic_Wrappers {
	private WebDriverException WebDriverwait;

	@Test
	public void p_test() throws Throwable
	{
		//invokeApp("chrome","http://abbwebsiteqa.shastatek.com/for-home/bundles/tivo-double-play");
		//invokeApp("chrome","http://abbwebsiteqa.shastatek.com/my-services/tv/channel-lineup");
		invokeApp("chrome","http://abbwebsiteqa.shastatek.com/my-services/my-account/refer-a-friend");
		/*enterById("zip_code", "33139");
		clickById("check_now");
		Thread.sleep(6000);*/
		System.out.println(driver.findElementByXPath("//div[@class='messaging error']").getText());
		/*System.out.println(driver.findElementByXPath("//a[@data-product='Tivo Double Play']/div/p").getText());
		String price = driver.findElementByXPath("//a[@data-product='Tivo Double Play']/div/p").getText().trim();
		String final_price=price.substring(0,price.indexOf("Limited")).trim();
		System.out.println(final_price);*/
		//verifyTextByXpath("//a[@data-product='Tivo Double Play']/div/p","$79.99");
/*verifyTextContainsByXpath("//a[@data-product='Tivo Double Play']/div/p", "$79.99");*/
	}


}