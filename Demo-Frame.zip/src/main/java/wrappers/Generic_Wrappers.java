package wrappers;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;
import utils.Reporter;
import org.testng.annotations.DataProvider;



public class Generic_Wrappers {
	public static RemoteWebDriver driver;
	int i;
	String parentHandle;
	public void takesnap()
	{File src = driver.getScreenshotAs(OutputType.FILE);
	try {
		FileUtils.copyFile(src, new File("./snaps/openTaps" + i + ".jpg"));
	} catch (IOException e) {
		System.out.println("SnapShot could not be taken");
	}catch (WebDriverException e) {
		System.out.println("The Browser could not be found");
	} 

	i++;


	}
	
	
	public boolean invokeApp(String browser, String Url)
	{
		boolean breturn = false;
		try {
			if (browser.equalsIgnoreCase("firefox"))
				driver = new FirefoxDriver();
			else if (browser.equalsIgnoreCase("chrome")) {
				System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
				driver = new ChromeDriver();
			}
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.get(Url);
			parentHandle = driver.getWindowHandle();
			System.out.println("The Browser: " + browser + " launched successfully");
			breturn = true;
		} catch (WebDriverException e) {
			System.out.println("The Browser could not be loaded");
		} catch (Exception e) {
			e.printStackTrace();

		}
		finally {
			//takeSnap();
		}
		return breturn;
	}

	public boolean enterById(String idValue, String data)

	{	boolean breturn = false;
	try {
		driver.findElementById(idValue).clear();
		driver.findElementById(idValue).sendKeys(data);
		breturn= true;
	} 
	catch(WebDriverException e)
	{
		System.out.println("The browser could not be loaded");
	}
	catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return breturn;
	}




	public boolean enterByXpath(String xpathValue, String data)
	{boolean breturn = false;
	try {
		driver.findElementByXPath(xpathValue).clear();
		driver.findElementByXPath(xpathValue).sendKeys(data);
		breturn = true;
	} catch (NoSuchElementException e) {
		System.out.println("There is no Element by Xpath: " + xpathValue);
	} catch (WebDriverException e) {
		System.out.println("The Browser could not be found");
	} finally {
		takeSnap();
	}

	return breturn;
	}

	public boolean clickByCssSelector(String cssVal) {
		boolean breturn = false;
		try {
			driver.findElementByCssSelector(cssVal).click();
			
			Reporter.reportStep("The Click  successfully in field :"+cssVal, "PASS");
			System.out.println("The element by css name " +cssVal+ "is found");
			breturn = true;
		} catch (NoSuchElementException e) {
			Reporter.reportStep("The Click Not successfully in field :"+cssVal,"FAIL");
			System.out.println("There is no Element by CssName: " + cssVal);
		} catch (WebDriverException e) {
			Reporter.reportStep("The Click Not successfully in field :"+cssVal,"FAIL");
			System.out.println("The Browser could not be found");
		} 
		catch (Exception e) {
			Reporter.reportStep("The Click Not successfully in field :"+cssVal,"FAIL");
		}
		
		/*finally {
			takeSnap();
		}*/ 
		
		return breturn;

	}
	/*public boolean enterByIdandClick(String idValue, String data)

	{	boolean breturn = false;
	try {
		driver.findElementById(idValue).clear();
		driver.findElementById(idValue).sendKeys(data);
		driver.findElementById(idValue).click();
		breturn= true;
	} 
	catch(WebDriverException e)
	{
		System.out.println("The browser could not be loaded");
	}
	catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return breturn;
	}*/
	
	public boolean verifyTextByXpath(String xpath, String text)  {
		boolean breturn = false; 
		try {
			
			if(driver.findElementByXPath(xpath).getText().equals(text)){
				System.out.println("The Expected text: "+text+" is available");

				breturn = true;
			}

			else{
				System.out.println("The Expected text: "+text+" is not available");
			}
		} catch (NoSuchElementException e){
			System.out.println("There is no Element by Xpath: "+xpath);
		}catch (WebDriverException e){
			System.out.println("The Browser could not be found");
		}
		finally{
			takeSnap();
		}
		return breturn;
	}

	public void selectVisibileTextById(String id, String value) {
		try {
			Select i = new Select(driver.findElement(By.id(id)));
			i.selectByVisibleText(value);
		} catch (NoSuchElementException e) {
			System.out.println("There is no Element by Id: " + id);
		} catch (WebDriverException e) {
			System.out.println("The Browser could not be found");
		} finally {
			takeSnap();
		}
	}


	public boolean enterByName(String nameValue, String data)

	{boolean breturn = false;
	return breturn;
	}
	public boolean verifyTitle(String title)

	{boolean breturn = false;
	return breturn;
	}

	public boolean verifyTextById(String id, String text)

	{boolean breturn = false;
	return breturn;
	}




	public boolean verifyTextContainsByXpath(String xpath, String text)

	{boolean breturn = false;
	return breturn;
	}

	public boolean verifyTextContainsById(String id, String text)
	{boolean breturn = false;
	return breturn;
	}

	public boolean clickById(String id)
	{boolean breturn = false;
	
	try {
		driver.findElementById(id).click();
		breturn = true;
		System.out.println("The element by id" +id + " is found");
	}catch (NoSuchElementException e){
		System.out.println("There is no Element by id: "+id);
	}catch (WebDriverException e){
		System.out.println("The Browser could not be found");
	}
	finally{
		takeSnap();
	} return breturn;
	

	}


	public boolean clickByClassName(String classVal)
	{boolean breturn = false;
	return breturn;
	}


	public boolean clickByName(String name)
	{boolean breturn = false;
	return breturn;
	}



	public boolean clickByLink(String name)
	{boolean breturn = false;
	return breturn;
	}


	public boolean clickByXpath(String xpathVal)

	{boolean breturn = false;
	return breturn;
	}

	public boolean gettextById(String idVal)

	{boolean breturn = false;
	return breturn;
	}

	public boolean getTextByXpath(String xpathVal)
	{boolean breturn = false;
	return breturn;
	}



	public void selectIndexById(String id, int value)
	{
	}


	public void switchToParentWindow()

	{
	}

	public void switchToLastWindow()
	{
	}


	public void acceptAlert()
	{
	}


	public void takeSnap()
	{
	}

	public void quit() {
		try {
			driver.quit();
		} catch (WebDriverException e){
			System.out.println("The Browser could not be found");
		}
		}
	

}
