package test_Sample;






import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;


import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import org.testng.annotations.Test;
import org.apache.poi.ss.usermodel.Cell;


public class Readtest {

@Test
public void readExcel() throws IOException
{
String Filepath="./Data/Read_Write.xlsx";

FileInputStream fs =new FileInputStream(Filepath);//Open the Excel
XSSFWorkbook excelWorkbook=new XSSFWorkbook(fs); // Access the required test data sheet
XSSFSheet sheet=excelWorkbook.getSheet("Test1");
int totnoRows=sheet.getLastRowNum();

//Create a loop over all the rows of excel file to read it

for(int i=0;i<=totnoRows;i++)
{
Row row =sheet.getRow(i);

for(int j=0;j<row.getLastCellNum();j++)
{
System.out.print(row.getCell(j)+"\t");
}
System.out.println();
}


}

@Test

public void WriteExcel() throws IOException
{
try{
String Filepath="./Data/Read_Write.xlsx";
FileInputStream fs =new FileInputStream(Filepath);//Open the Excel
XSSFWorkbook wbWrite=new XSSFWorkbook(fs);
XSSFSheet wrsheet=wbWrite.getSheet("Test1");
XSSFRow sercell=wrsheet.getRow(2);
XSSFCell setv=sercell.createCell(2);
setv.setCellValue("Azhar");
//fs.close();

FileOutputStream outFile =new FileOutputStream(new File("./Data/Read_Write.xlsx"));
wbWrite.write(outFile);
outFile.close();
int totnoRows=wrsheet.getLastRowNum();

//Create a loop over all the rows of excel file to read it

for(int i=0;i<=totnoRows;i++)
{
Row row =wrsheet.getRow(i);

for(int j=0;j<row.getLastCellNum();j++)
{
System.out.print(row.getCell(j)+"\t");
}
System.out.println();
}

}
catch(Exception e)
{
e.printStackTrace();
}
}

}
