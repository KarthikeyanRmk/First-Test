package forms;


import java.util.List;
import java.util.concurrent.TimeUnit;



import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import org.openqa.selenium.support.ui.Select;

import wrappers.Generic_Wrappers;

public    class Refer_A_Friend extends Generic_Wrappers {
	//static FirefoxDriver driver= new FirefoxDriver();

	/*public static void scenario2()
	{	FirefoxDriver driver= new FirefoxDriver();
	driver.navigate().to("http://abbwebsiteqa.shastatek.com/my-services/my-account/refer-a-friend");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
	new Select(driver.findElementById("how_did_you_hear")).selectByVisibleText("Bill Message");

	driver.findElementByCssSelector("input[ type=\"submit\"]").click();
	List<WebElement> line= driver.findElementsByXPath("//*[@id='refer_a_friend']/div/div/section/div/ul/li");
	int j=line.size();
	System.out.println( "Scenario 2:Total Error Count"+j);
	for ( int i=0; i < line.size(); i++) {
		System.out.println(line.get(i).getText());
	}
	if (j==0)
		System.out.println("Form submit successfully");
	else
		System.out.println("Form submission have some  error");
	System.out.println("");
	driver.close();
	}



	public static void scenario3()
	{	FirefoxDriver driver= new FirefoxDriver();
	driver.navigate().to("http://abbwebsiteqa.shastatek.com/my-services/my-account/refer-a-friend");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
	new Select(driver.findElementById("how_did_you_hear")).selectByVisibleText("Bill Message");
	driver.findElementById("first_name").sendKeys("Test");
	driver.findElementByCssSelector("input[ type=\"submit\"]").click();
	List<WebElement> line= driver.findElementsByXPath("//*[@id='refer_a_friend']/div/div/section/div/ul/li");
	
	int j=line.size();
	System.out.println( "Scenario 3:Total Error Count:"+j);
	for ( int i=0; i < line.size(); i++) {
		System.out.println(line.get(i).getText());
	}

	if (j==0)
		System.out.println("Form submit successfully");
	else
		System.out.println("Form submission have some  error");
	System.out.println("");
	
	}


	public static void scenario4()
	{	FirefoxDriver driver= new FirefoxDriver();
	driver.navigate().to("http://abbwebsiteqa.shastatek.com/my-services/my-account/refer-a-friend");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
	new Select(driver.findElementById("how_did_you_hear")).selectByVisibleText("Bill Message");
	driver.findElementById("first_name").sendKeys("Test");
	driver.findElementById("last_name").sendKeys("Test");
	driver.findElementByCssSelector("input[ type=\"submit\"]").click();
	List<WebElement> line= driver.findElementsByXPath("//*[@id='refer_a_friend']/div/div/section/div/ul/li");
	int j=line.size();
	System.out.println( "Scenario 4:Total Error Count:"+j);
	for ( int i=0; i < line.size(); i++) {
		System.out.println(line.get(i).getText());
	}

	if (j==0)
		System.out.println("Form submit successfully");
	else
		System.out.println("Form submission have some  error");
	System.out.println("");
	driver.close();
	}

	public static void scenario5()
	{	FirefoxDriver driver= new FirefoxDriver();
	driver.navigate().to("http://abbwebsiteqa.shastatek.com/my-services/my-account/refer-a-friend");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
	new Select(driver.findElementById("how_did_you_hear")).selectByVisibleText("Bill Message");
	driver.findElementById("first_name").sendKeys("Test");
	driver.findElementById("last_name").sendKeys("Test");
	driver.findElementById("address").sendKeys("Test");
	driver.findElementByCssSelector("input[ type=\"submit\"]").click();
	List<WebElement> line= driver.findElementsByXPath("//*[@id='refer_a_friend']/div/div/section/div/ul/li");
	int j=line.size();
	System.out.println( "Scenario 5:Total Error Count:"+j);
	for ( int i=0; i < line.size(); i++) {
		System.out.println(line.get(i).getText());
	}

	if (j==0)
		System.out.println("Form submit successfully");
	else
		System.out.println("Form submission have some  error");
	System.out.println("");
	driver.close();
	}

	public static void scenario6()
	{	FirefoxDriver driver= new FirefoxDriver();
	driver.navigate().to("http://abbwebsiteqa.shastatek.com/my-services/my-account/refer-a-friend");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
	new Select(driver.findElementById("how_did_you_hear")).selectByVisibleText("Bill Message");
	driver.findElementById("first_name").sendKeys("Test");
	driver.findElementById("last_name").sendKeys("Test");
	driver.findElementById("address").sendKeys("Test");
	driver.findElementById("city").sendKeys("Test");
	driver.findElementByCssSelector("input[ type=\"submit\"]").click();
	List<WebElement> line= driver.findElementsByXPath("//*[@id='refer_a_friend']/div/div/section/div/ul/li");
	int j=line.size();
	System.out.println( "Scenario 6:Total Error Count:"+j);
	for ( int i=0; i < line.size(); i++) {
		System.out.println(line.get(i).getText());
	}

	if (j==0)
		System.out.println("Form submit successfully");
	else
		System.out.println("Form submission have some  error");
	System.out.println("");
	driver.close();
	}

	public static void scenario7()
	{	FirefoxDriver driver= new FirefoxDriver();
	driver.navigate().to("http://abbwebsiteqa.shastatek.com/my-services/my-account/refer-a-friend");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
	new Select(driver.findElementById("how_did_you_hear")).selectByVisibleText("Bill Message");
	driver.findElementById("first_name").sendKeys("Test");
	driver.findElementById("last_name").sendKeys("Test");
	driver.findElementById("address").sendKeys("Test");
	driver.findElementById("city").sendKeys("Test");
	driver.findElementById("zip").sendKeys("65412");
	driver.findElementByCssSelector("input[ type=\"submit\"]").click();
	List<WebElement> line= driver.findElementsByXPath("//*[@id='refer_a_friend']/div/div/section/div/ul/li");
	int j=line.size();
	System.out.println( "Scenario 7:Total Error Count:"+j);
	for ( int i=0; i < line.size(); i++) {
		System.out.println(line.get(i).getText());
	}

	if (j==0)
		System.out.println("Form submit successfully");
	else
		System.out.println("Form submission have some  error");
	System.out.println("");
	driver.close();
	}

	public static void scenario8()
	{	FirefoxDriver driver= new FirefoxDriver();
	driver.navigate().to("http://abbwebsiteqa.shastatek.com/my-services/my-account/refer-a-friend");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
	new Select(driver.findElementById("how_did_you_hear")).selectByVisibleText("Bill Message");
	driver.findElementById("first_name").sendKeys("Test");
	driver.findElementById("last_name").sendKeys("Test");
	driver.findElementById("address").sendKeys("Test");
	driver.findElementById("city").sendKeys("Test");
	driver.findElementById("zip").sendKeys("65412");
	new Select(driver.findElementById("state")).selectByVisibleText("California");
	driver.findElementByCssSelector("input[ type=\"submit\"]").click();
	List<WebElement> line= driver.findElementsByXPath("//*[@id='refer_a_friend']/div/div/section/div/ul/li");
	int j=line.size();
	System.out.println( "Scenario 8:Total Error Count:"+j);
	for ( int i=0; i < line.size(); i++) {
		System.out.println(line.get(i).getText());
	}

	if (j==0)
		System.out.println("Form submit successfully");
	else
		System.out.println("Form submission have some  error");
	System.out.println("");
	driver.close();
	}

	public static void scenario9()
	{	FirefoxDriver driver= new FirefoxDriver();
	driver.navigate().to("http://abbwebsiteqa.shastatek.com/my-services/my-account/refer-a-friend");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
	new Select(driver.findElementById("how_did_you_hear")).selectByVisibleText("Bill Message");
	driver.findElementById("first_name").sendKeys("Test");
	driver.findElementById("last_name").sendKeys("Test");
	driver.findElementById("address").sendKeys("Test");
	driver.findElementById("city").sendKeys("Test");
	driver.findElementById("zip").sendKeys("65412");
	new Select(driver.findElementById("state")).selectByVisibleText("California");
	driver.findElementById("phone").sendKeys("9876543210");
	driver.findElementByCssSelector("input[ type=\"submit\"]").click();
	List<WebElement> line= driver.findElementsByXPath("//*[@id='refer_a_friend']/div/div/section/div/ul/li");
	int j=line.size();
	System.out.println( "Scenario 9:Total Error Count:"+j);
	for ( int i=0; i < line.size(); i++) {
		System.out.println(line.get(i).getText());
	}

	if (j==0)
		System.out.println("Form submit successfully");
	else
		System.out.println("Form submission have some  error");
	System.out.println("");
	driver.close();
	}

	public static void scenario10()
	{	FirefoxDriver driver= new FirefoxDriver();
	driver.navigate().to("http://abbwebsiteqa.shastatek.com/my-services/my-account/refer-a-friend");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
	new Select(driver.findElementById("how_did_you_hear")).selectByVisibleText("Bill Message");
	driver.findElementById("first_name").sendKeys("Test");
	driver.findElementById("last_name").sendKeys("Test");
	driver.findElementById("address").sendKeys("Test");
	driver.findElementById("city").sendKeys("Test");
	driver.findElementById("zip").sendKeys("65412");
	new Select(driver.findElementById("state")).selectByVisibleText("California");
	driver.findElementById("phone").sendKeys("9876543210");
	driver.findElementById("email").sendKeys("Test");
	driver.findElementByCssSelector("input[ type=\"submit\"]").click();
	List<WebElement> line= driver.findElementsByXPath("//*[@id='refer_a_friend']/div/div/section/div/ul/li");
	int j=line.size();
	System.out.println( "Scenario 10:Total Error Count:"+j);
	for ( int i=0; i < line.size(); i++) {
		System.out.println(line.get(i).getText());
	}

	if (j==0)
		System.out.println("Form submit successfully");
	else
		System.out.println("Form submission have some  error");
	System.out.println("");
	driver.close();
	}

	public static void scenario11()
	{	FirefoxDriver driver= new FirefoxDriver();
	driver.navigate().to("http://abbwebsiteqa.shastatek.com/my-services/my-account/refer-a-friend");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
	new Select(driver.findElementById("how_did_you_hear")).selectByVisibleText("Bill Message");
	driver.findElementById("first_name").sendKeys("Test");
	driver.findElementById("last_name").sendKeys("Test");
	driver.findElementById("address").sendKeys("Test");
	driver.findElementById("city").sendKeys("Test");
	driver.findElementById("zip").sendKeys("65412");
	new Select(driver.findElementById("state")).selectByVisibleText("California");
	driver.findElementById("phone").sendKeys("9876543210");
	driver.findElementById("email").sendKeys("Test");
	driver.findElementById("friend_1_first_name").sendKeys("Test");
	driver.findElementByCssSelector("input[ type=\"submit\"]").click();
	List<WebElement> line= driver.findElementsByXPath("//*[@id='refer_a_friend']/div/div/section/div/ul/li");
	int j=line.size();
	System.out.println( "Scenario 11:Total Error Count:"+j);
	for ( int i=0; i < line.size(); i++) {
		System.out.println(line.get(i).getText());
	}

	if (j==0)
		System.out.println("Form submit successfully");
	else
		System.out.println("Form submission have some  error");
	System.out.println("");
	driver.close();
	}

	public static void scenario12()
	{	FirefoxDriver driver= new FirefoxDriver();
	driver.navigate().to("http://abbwebsiteqa.shastatek.com/my-services/my-account/refer-a-friend");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
	new Select(driver.findElementById("how_did_you_hear")).selectByVisibleText("Bill Message");
	driver.findElementById("first_name").sendKeys("Test");
	driver.findElementById("last_name").sendKeys("Test");
	driver.findElementById("address").sendKeys("Test");
	driver.findElementById("city").sendKeys("Test");
	driver.findElementById("zip").sendKeys("65412");
	new Select(driver.findElementById("state")).selectByVisibleText("California");
	driver.findElementById("phone").sendKeys("9876543210");
	driver.findElementById("email").sendKeys("Test");
	driver.findElementById("friend_1_first_name").sendKeys("Test");
	driver.findElementById("friend_1_last_name").sendKeys("Test");
	driver.findElementByCssSelector("input[ type=\"submit\"]").click();
	List<WebElement> line= driver.findElementsByXPath("//*[@id='refer_a_friend']/div/div/section/div/ul/li");
	int j=line.size();
	System.out.println( "Scenario 12:Total Error Count:"+j);
	for ( int i=0; i < line.size(); i++) {
		System.out.println(line.get(i).getText());
	}

	if (j==0)
		System.out.println("Form submit successfully");
	else
		System.out.println("Form submission have some  error");
	System.out.println("");
	driver.close();
	}

	public static void scenario13()
	{	FirefoxDriver driver= new FirefoxDriver();
	driver.navigate().to("http://abbwebsiteqa.shastatek.com/my-services/my-account/refer-a-friend");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
	new Select(driver.findElementById("how_did_you_hear")).selectByVisibleText("Bill Message");
	driver.findElementById("first_name").sendKeys("Test");
	driver.findElementById("last_name").sendKeys("Test");
	driver.findElementById("address").sendKeys("Test");
	driver.findElementById("city").sendKeys("Test");
	driver.findElementById("zip").sendKeys("65412");
	new Select(driver.findElementById("state")).selectByVisibleText("California");
	driver.findElementById("phone").sendKeys("9876543210");
	driver.findElementById("email").sendKeys("Test");
	driver.findElementById("friend_1_first_name").sendKeys("Test");
	driver.findElementById("friend_1_last_name").sendKeys("Test");
	driver.findElementById("friend_1_phone").sendKeys("Test");
	driver.findElementByCssSelector("input[ type=\"submit\"]").click();
	List<WebElement> line= driver.findElementsByXPath("//*[@id='refer_a_friend']/div/div/section/div/ul/li");
	int j=line.size();
	System.out.println( "Scenario 13:Total Error Count:"+j);
	for ( int i=0; i < line.size(); i++) {
		System.out.println(line.get(i).getText());
	}

	if (j==0)
		System.out.println("Form submit successfully");
	else
		System.out.println("Form submission have some  error");
	System.out.println("");
	driver.close();
	}

	public static void scenario14()
	{	FirefoxDriver driver= new FirefoxDriver();
	driver.navigate().to("http://abbwebsiteqa.shastatek.com/my-services/my-account/refer-a-friend");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
	new Select(driver.findElementById("how_did_you_hear")).selectByVisibleText("Bill Message");
	driver.findElementById("first_name").sendKeys("Test");
	driver.findElementById("last_name").sendKeys("Test");
	driver.findElementById("address").sendKeys("Test");
	driver.findElementById("city").sendKeys("Test");
	driver.findElementById("zip").sendKeys("65412");
	new Select(driver.findElementById("state")).selectByVisibleText("California");
	driver.findElementById("phone").sendKeys("9876543210");
	driver.findElementById("email").sendKeys("Test");
	driver.findElementById("friend_1_first_name").sendKeys("Test");
	driver.findElementById("friend_1_last_name").sendKeys("Test");
	driver.findElementById("friend_1_phone").sendKeys("Test");
	driver.findElementById("friend_1_zip").sendKeys("Test");
	driver.findElementByCssSelector("input[ type=\"submit\"]").click();
	List<WebElement> line= driver.findElementsByXPath("//*[@id='refer_a_friend']/div/div/section/div/ul/li");
	int j=line.size();
	System.out.println( "Scenario 14:Total Error Count:"+j);
	for ( int i=0; i < line.size(); i++) {
		System.out.println(line.get(i).getText());
	}

	if (j==0)
		System.out.println("Form submit successfully");
	else
		System.out.println("Form submission have some  error");
	System.out.println("");
	driver.close();
	}*/

	public static void scenario15()
	{	FirefoxDriver driver= new FirefoxDriver();
	driver.navigate().to("http://abbwebsiteqa.shastatek.com/my-services/my-account/refer-a-friend");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
	new Select(driver.findElementById("how_did_you_hear")).selectByVisibleText("Bill Message");
	driver.findElementById("first_name").sendKeys("Test");
	driver.findElementById("last_name").sendKeys("Test");
	driver.findElementById("address").sendKeys("Test");
	driver.findElementById("city").sendKeys("Test");
	driver.findElementById("zip").sendKeys("65412");
	new Select(driver.findElementById("state")).selectByVisibleText("California");
	driver.findElementById("phone").sendKeys("9876543210");
	driver.findElementById("email").sendKeys("Test");
	driver.findElementById("friend_1_first_name").sendKeys("Test");
	driver.findElementById("friend_1_last_name").sendKeys("Test");
	driver.findElementById("friend_1_phone").sendKeys("Test");
	driver.findElementById("friend_1_zip").sendKeys("Test");
	driver.findElementById("friend_1_email").sendKeys("Test");

	driver.findElementByCssSelector("input[ type=\"submit\"]").click();
	/*List<WebElement> line= driver.findElementsByXPath("//*[@id='refer_a_friend']/div/div/section/div/ul/li");
	int j=line.size();
	System.out.println( "Scenario 15:Total Error Count:"+j);
	for ( int i=0; i < line.size(); i++) {
		System.out.println(line.get(i).getText());
	}

	if (j==0)
		System.out.println("Form submit successfully");
	else
		System.out.println("Form submission have some  error");
		
	System.out.println("");*/
	
	driver.close();
	}
	/*public static void scenario1()
	{
		FirefoxDriver driver= new FirefoxDriver();
		driver.navigate().to("http://abbwebsiteqa.shastatek.com/my-services/my-account/refer-a-friend");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);

		new Select(driver.findElementById("how_did_you_hear")).selectByVisibleText("Bill Message");;
		driver.findElementById("first_name").sendKeys("Test");
		driver.findElementById("last_name").sendKeys("Test");
		driver.findElementById("address").sendKeys("Test");
		driver.findElementById("city").sendKeys("Test");
		driver.findElementById("zip").sendKeys("65412");
		//Dropdown

		new Select(driver.findElementById("state")).selectByVisibleText("California");
		driver.findElementById("phone").sendKeys("9876543210");
		driver.findElementById("phone_ab_account").sendKeys("98765432101236");
		driver.findElementById("email").sendKeys("Test@gmail.com");

		driver.findElementById("friend_1_first_name").sendKeys("Test");
		driver.findElementById("friend_1_last_name").sendKeys("Test");
		driver.findElementById("friend_1_phone").sendKeys("98744");
		driver.findElementById("friend_1_zip").sendKeys("86431");
		driver.findElementById("friend_1_email").sendKeys("Test@gmail.com");






		driver.findElementByCssSelector("input[ type=\"submit\"]").click();
		//WebElement allerror =driver.findElementByXPath("//*[@id='refer_a_friend']/div/div/section/div");
		//List<WebElement> line= allerror.findElements(By.tagName("ul"));
		List<WebElement> line= driver.findElementsByXPath("//*[@id='refer_a_friend']/div/div/section/div/ul/li");
		int j=line.size();
		System.out.println( "Scenario 1:Total Error Count "+j);
		for ( int i=0; i < line.size(); i++) {
			System.out.println(line.get(i).getText());
		}
		if (j==0)
			System.out.println("Form submit successfully");
		else
			System.out.println("Form submission have some  error");
		System.out.println("");
		driver.close();
	}*/
	public static void main(String[] args) {


		/*scenario2();
		scenario3();
		scenario4();
		scenario5();
		scenario6();
		scenario7();
		scenario8();
		scenario9();
		scenario10();
		scenario11();
		scenario12();
		scenario13();
		scenario14();*/
		scenario15();
		//scenario1();


	}


}
