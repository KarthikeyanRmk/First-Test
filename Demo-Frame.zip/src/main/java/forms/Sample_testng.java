package forms;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;

public class Sample_testng {
	FirefoxDriver driver =new FirefoxDriver();
  @Test
  public void f() {
	 
	 
	  driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	  
  }
  @Test
  public void second()
  {
	  
	  System.out.println(driver.getCurrentUrl());  
  }
  @Test
  public void first()
  {

	  System.out.println(driver.getTitle());
	  
  }
  @BeforeMethod
  public void beforeMethod() {
	  
	  driver.get("https://google.co.in");
	
  }

  @AfterMethod
  public void afterMethod() {
	  driver.manage().window().maximize();
	 
	
  }

}
